#include <stdio.h>
#include <string.h>

typedef struct {
    char aircraftType[50];
    int flightNumber;
    int seats;
    int passengers;
} Flight;

Flight inputFlight() {
    Flight f;
    printf("Dwse ton typo tou aeroskafous: ");
    scanf(" %[^\n]", f.aircraftType);  
    printf("Dwse ton arithmo pthshs: ");
    scanf("%d", &f.flightNumber);
    printf("Dwse ton arithmo thesewn tou aeroskafous: ");
    scanf("%d", &f.seats);
    printf("Dwse ton arithmo twn epivatwn: ");
    scanf("%d", &f.passengers);
    return f;
}
Flight flightWithMaxOccupancy(Flight flights[], int n) {
    int maxPassengers = -1;
    int index = -1;
    for(int i = 0; i < n; i++) {
        double occupancy = (double)flights[i].passengers / flights[i].seats;
        if(occupancy > maxPassengers / (double)flights[index].seats) {
            maxPassengers = flights[i].passengers;
            index = i;
        }
    }
    return flights[index];
}

int main() {
    const int NUM_FLIGHTS = 5;
    Flight flights[NUM_FLIGHTS];

    for(int i = 0; i < NUM_FLIGHTS; i++) {
        printf("\nPthsh %d:\n", i + 1);
        flights[i] = inputFlight();
    }

    
    int totalPassengers = 0;
    int fullFlights = 0;
    for(int i = 0; i < NUM_FLIGHTS; i++) {
        totalPassengers += flights[i].passengers;
        if((double)flights[i].passengers / flights[i].seats >= 0.8) {
            fullFlights++;
        }
    }

    printf("\nSynolikos arithmos epivatwn: %d\n", totalPassengers);
    printf("Arithmos ptisewn me plhrothta >= 80%%: %d\n", fullFlights);

    Flight maxFlight = flights[0];
    double maxOccupancy = (double)flights[0].passengers / flights[0].seats;
    for(int i = 1; i < NUM_FLIGHTS; i++) {
        double occupancy = (double)flights[i].passengers / flights[i].seats;
        if(occupancy > maxOccupancy) {
            maxOccupancy = occupancy;
            maxFlight = flights[i];
        }
    }

    printf("\nPthsh me thn megalyterh plhrothta:\n");
    printf("Typos aeroskafous: %s\n", maxFlight.aircraftType);
    printf("Arithmos pthshs: %d\n", maxFlight.flightNumber);
    printf("Arithmos thesewn: %d\n", maxFlight.seats);
    printf("Arithmos epivatwn: %d\n", maxFlight.passengers);

    return 0;
}
